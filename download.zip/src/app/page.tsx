import HomeClient from "./home-client";

export default function HomePage() {
  return <HomeClient />;
}
